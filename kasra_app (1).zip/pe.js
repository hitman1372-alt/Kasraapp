const {chromium}=require('/app/browser/node_modules/playwright-core');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
p.on('pageerror',e=>console.log('PAGEERR',e.message));p.on('console',m=>m.type()=='error'&&console.log('CERR',m.text()));
p.on('dialog',d=>d.dismiss());
await p.goto('/tmp/k.html');await p.waitForTimeout(1500);
console.log(await p.evaluate(()=>document.body.innerText.slice(0,200)));await b.close()})()
